# design/ — companion app UI

Design artifacts for the TexasInvestors pipeline. These are HTML design
deliverables, not application code: no build step, no server, and nothing
here imports the Python modules. They specify what the UI should do and look
like before it is implemented.

Drop this folder at the repo root and commit it. Nothing outside `design/`
is touched.

## Files

| File | What it is |
| --- | --- |
| `Map.html` | Standalone lead map. Leaflet + OpenStreetMap tiles, score-coded pins, signal/status/score filters, lead rail, ZIP search. Open directly in a browser. |
| `TexasInvestors Platform.dc.html` | The main screen set: Dashboard, Lead explorer, Lead detail ("Why this lead?"), Pipeline board, Data sources, Runs, plus a mobile tab flow. Open directly in a browser; needs `support.js` beside it. |
| `support.js` | Runtime for the `.dc.html` page. Generated — do not hand-edit. |
| `_ds/modernist-…/styles.css` | Design-system token sheet: colors, type, spacing, 0px radius, 2px rules. Both pages link it. |
| `_ds/modernist-…/readme.md` | The design system's own guide. |

## Ground rules these designs follow

**Nothing is faked as real.** Addresses, owners of record and mailing
addresses are actual rows from `output/hcad_top_absentee_leads.csv`. Anything
the live pipeline cannot produce today carries a visible **FIXTURE** badge.

Two consequences are deliberately visible in the UI rather than designed
around:

1. **Almost every live lead scores 1.** Probate filings carry no address,
   foreclosure postings carry neither address nor owner, and tax amounts
   arrive only by manual CSV — so `match.py` has little to join on. The
   dashboard says this in plain language instead of showing a flattering
   score distribution.
2. **Every map pin is a demo position.** `properties.latitude` /
   `.longitude` are unpopulated for all 299 leads. The map carries a
   persistent GEOCODING PENDING banner and dashed pin borders.

**Scores are counts, not predictions.** The detail view labels the score a
"raw signal count" and shows each contributing source record as it arrived,
with the join basis (block key, thresholds, which fuzz function) spelled out.
Any row can be rejected, and the count recomputes from what remains.

**Source status is honest.** The Data sources screen distinguishes
operational / limited / blocked / not configured. The Runs screen reports
PARTIAL SUCCESS whenever any source is degraded — a run with gated
foreclosure pagination never shows green.

**No information by color alone.** Every distress signal renders as a colored
swatch *plus* a text label, in every view.

## Where each screen's content came from

| Screen | Source of truth |
| --- | --- |
| Dashboard | `README.md` (299 / 199 / 100 counts), `match.py`, `audit_log.py` |
| Lead explorer | `models.py` (LeadRecord fields), `match.py` (sort order, distress_score) |
| Lead detail — evidence | `match.py` (ADDRESS/OWNER_MATCH_THRESHOLD, block key, the fuzz.ratio-over-WRatio rationale) |
| Lead detail — record | `models.py`, `scripts/hcad_top_absentee_leads.py` |
| Map | `README.md` (no geocoding today); positions are demo |
| Data sources | `README.md` source status table, `site_adapters/base.py` (robots.txt fail-closed) |
| Runs | `README.md` (partial-success semantics), `audit_log.py` |

## Signal vocabulary used in the UI

`probate`, `trustee_sale`, `tax_delinquent`, `absentee_owner` come from
`models.py`. `out_of_state` is the derived signal
`scripts/hcad_top_absentee_leads.py` already computes via `WEIGHTS`. The UI
reads signals as a list, so adding a type is a data change, not a redesign.

## Known deviations

- The design system specifies Archivo throughout. IBM Plex Mono is used for
  record IDs, case numbers, amounts and dates, where character-by-character
  comparison matters more than typographic consistency.
- Skip-trace phone numbers are shown as investor-entered data, stored
  separately from public source records. Fixture values only.
